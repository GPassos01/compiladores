/*
 * lexer.c
 *
 * Implementation of lexical analysis functions for tokenizing input.
 *
 * Authors: 
 *  - Felipe Melchior de Britto
 *  - João Henrique Botelho
 *  - Ryan Hideki Tadeo Guimarães
 * Date: 2025-09-04
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <lexer.h>

/* Buffer to store the current lexeme */
char lexeme[MAXIDLEN + 1];


/**
 * Checks if the next token is an identifier (ID).
 * Regex: [A-Za-z][A-Za-z0-9]*
 * @param tape Input file pointer
 * @return ID token if found, 0 otherwise
 */
int isID(FILE *tape)
{
    if (isalpha(lexeme[0] = getc(tape))) {
        int i = 1;
        while (isalnum(lexeme[i] = getc(tape))) i++;
        ungetc(lexeme[i], tape);
        lexeme[i] = 0;
        return ID;
    }
    ungetc(lexeme[0], tape);
    lexeme[0] = 0;
    return 0;
}


/**
 * Checks if the next token is a decimal number (DEC).
 * Regex: [1-9][0-9]* | '0'
 * @param tape Input file pointer
 * @return DEC token if found, 0 otherwise
 */
int isDEC(FILE *tape) {

    if (isdigit(lexeme[0] = getc(tape))) {

        if (lexeme[0] == '0') {
            return DEC;
        }

        int i = 1;
        while (isdigit(lexeme[i] = getc(tape))) i++;
        ungetc(lexeme[i], tape);
        lexeme[i] = 0;
        return DEC;
    }

    ungetc(lexeme[0], tape);
    lexeme[0] = 0;
    return 0;
}



/**
 * Checks for exponent part (EE) in floating point numbers.
 * Regex: [eE]['+''-']?[0-9][0-9]*
 * @param tape Input file pointer
 * @return FLT token if found, 0 otherwise
 */
int isEE(FILE *tape) {

    int i = strlen(lexeme);
    if ( toupper(lexeme[i] = getc(tape)) == 'E'){
        i++;

        // check optional sign
        int hassign;
        if( (lexeme[i] = getc(tape)) == '+' || lexeme[1] == '-') {
            hassign = i++ ;
        }
        else {
            hassign = 0;
            ungetc(lexeme[i], tape);
        }

        //check required digit following
        if( isdigit(lexeme[i] = getc(tape))) {
            i++;
            while( isdigit(lexeme[i] = getc(tape))) i++;
            ungetc(lexeme[i], tape);
            lexeme[i] = 0;
            return FLT;
        }
        ungetc(lexeme[i], tape);
        i--;
        if(hassign) {
            ungetc(lexeme[i], tape);
            i--;
        }

    }
    ungetc(lexeme[i], tape);
    lexeme[i] = 0;
    return 0;

}


/**
 * Checks if the next token is a number (integer or float).
 * Supports DEC, FLT, EE formats.
 * @param tape Input file pointer
 * @return token type (DEC, FLT) or 0 if not a number
 */
int isNUM(FILE *tape) {

    int token = isDEC(tape);
    if(token) {

        int i = strlen(lexeme);
        if((lexeme[1] = getc(tape)) == '.') {

            i++;
            while( isdigit( lexeme[i] =  getc(tape))) i++;
            ungetc(lexeme[i], tape);
            lexeme[i] = 0;
            token = FLT;
        }
        else {

            ungetc(lexeme[i], tape);
            lexeme[i] = 0;
        }
    }
    else {

        if( (lexeme[0] = getc(tape)) == '.') {

            if( isdigit( lexeme[1] = getc(tape))) {

                token = FLT;
                int i = 2;
                while( isdigit( lexeme[i] = getc(tape))) i++;
            }
            else {

                ungetc(lexeme[1], tape);
                ungetc(lexeme[0], tape);
                lexeme[0] = 0;
                return 0; // not a number

            }
        }
        else {
            ungetc(lexeme[0], tape);
            lexeme[0] = 0;
            return 0; // not a number
        }
    }

    if( isEE(tape)) {
        
        token = FLT;
    }
    return token;
}


/**
 * Checks if the next token is an octal number (OCT).
 * Regex: '0'[0-7]*
 * @param tape Input file pointer
 * @return OCT token if found, 0 otherwise
 */
int isOCT(FILE *tape){

    if ((lexeme[0] = getc(tape)) == '0') {

        int i = 1;
        if((lexeme[i] = getc(tape)) >= '0' && lexeme[i] <='7') {

            i = 2;
            while((lexeme[i] = getc(tape)) >= '0' && lexeme[i] <='7') i++;
            ungetc(lexeme[i], tape);
            lexeme[i] = 0;
            return OCT;

        }
        ungetc(lexeme[1], tape);
        lexeme[1] = 0;
        ungetc(lexeme[0], tape);
        lexeme[0] = 0;
        return 0;
    }

    ungetc(lexeme[0], tape);
    lexeme[0] = 0;
    return 0;
}


/**
 * Checks if the next token is a hexadecimal number (HEX).
 * Regex: '0'[Xx][0-9A-Fa-f]*
 * @param tape Input file pointer
 * @return HEX token if found, 0 otherwise
 */
int isHEX(FILE *tape) {

    if ((lexeme[0] = getc(tape)) == '0'){

        if ( toupper(lexeme[1] = getc(tape)) == 'X'){

            if ( isxdigit(lexeme[2] = getc(tape)) ){

                int i = 3;
                while( isxdigit(lexeme[i] = getc(tape)) ) i++;
                ungetc(lexeme[i], tape);
                lexeme[i] = 0;
                return HEX;
            }
            ungetc(lexeme[2], tape);
            lexeme[2] = 0;
            ungetc(lexeme[1], tape);
            lexeme[1] = 0;
            ungetc(lexeme[0], tape);
            lexeme[0] = 0;
            return 0;
        }
        ungetc(lexeme[1], tape);
        lexeme[1] = 0;
        ungetc(lexeme[0], tape);
        lexeme[0] = 0;
        return 0;
    }

    ungetc(lexeme[0], tape);
    lexeme[0] = 0;
    return 0;
}


/**
 * Skips whitespace characters in the input stream.
 * @param tape Input file pointer
 */
void skipspaces(FILE *tape) {
    int head;
    while (isspace(head = getc(tape)));
    ungetc(head, tape);
}


/**
 * Gets the next token from the input stream.
 * Tries ID, HEX, OCT, DEC, or returns ASCII token.
 * @param source Input file pointer
 * @return Token type or ASCII value
 */
int gettoken(FILE *source)
{
    int token;
    skipspaces(source);
    if ((token = isID(source))) return token;
    if ((token = isHEX(source))) return token;
    if ((token = isOCT(source))) return token;
    if ((token = isDEC(source))) return token;
    token = getc(source);
    /* Return ASCII token if no other match */
    return token;
}
