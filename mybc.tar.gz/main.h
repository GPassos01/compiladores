
/*
 * main.h
 *
 * Header for main compiler functions and global variables.
 *
 * Authors:
 *  - Felipe Melchior de Britto
 *  - João Henrique Botelho
 *  - Ryan Hideki Tadeo Guimarães
 * Date: 2025-09-04
 */

/**
 * Gets the next token from the input stream.
 * @param FILE* pointer to input source
 * @return token type or ASCII value
 */
extern int gettoken(FILE *);

/**
 * Lookahead token for parser.
 */
extern int lookahead;

/**
 * Entry point for parsing expressions or grammar.
 */
extern void E(void);