
/*
 * main.c
 *
 * Entry point for the compiler front-end.
 * Authors: 
 *  - Felipe Melchior de Britto
 *  - João Henrique Botelho
 *  - Ryan Hideki Tadeo Guimarães
 * Date: 2025-09-04
 */

#include <stdio.h>
#include <stdlib.h>
#include <main.h>

/**
 * Global file pointer for the source input.
 */
FILE *source;

/**
 * Main function: initializes lookahead and starts parsing.
 * @return Exit status
 */
int main(void) {
    lookahead = gettoken(source = stdin); // Initialize lookahead with first token
    E(); // Start parsing (expression or grammar entry)
    return 0;
}