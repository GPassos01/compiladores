
/*
 * parser.h
 *
 * Header for recursive descent parser functions and global variables.
 *
 * Authors:
 *  - Felipe Melchior de Britto
 *  - João Henrique Botelho
 *  - Ryan Hideki Tadeo Guimarães
 * Date: 2025-09-04
 */

/** Error code for token mismatch */
#define ERRTOKEN -0x10000000

/** Lookahead token for parser */
extern int lookahead;
/** Global file pointer for source input */
extern FILE *source;

/**
 * Matches the expected token and advances lookahead.
 * @param expected Expected token value
 */
extern void match(int);

/**
 * Gets the next token from the input stream.
 * @param FILE* pointer to input source
 * @return token type or ASCII value
 */
extern int gettoken(FILE *);

/**
 * E is the start symbol of the LL(1) grammar for simplified expressions.
 * Production: E -> T R
 */
extern void E(void);

/**
 * T non-terminal.
 * Production: T -> F Q
 */
extern void T(void);

/**
 * F non-terminal.
 * Production: F -> '(' E ')' | DEC | OCT | HEX | FLT | ID
 */
extern void F(void);

/**
 * Q non-terminal.
 * Production: Q -> '*' F Q | '/' F Q | epsilon
 */
extern void Q(void);

/**
 * R non-terminal.
 * Production: R -> '+' T R | '-' T R | epsilon
 */
extern void R(void);
