
/*
 * lexer.h
 *
 * Header for lexical analysis definitions and token types.
 * Authors: 
 *  - Felipe Melchior de Britto
 *  - João Henrique Botelho
 *  - Ryan Hideki Tadeo Guimarães
 * Date: 2025-09-04
 */

/** Maximum length for identifiers */
#define MAXIDLEN 256

/** Buffer for the current lexeme */
extern char lexeme[];

/**
 * Token type enumeration for lexical analysis
 * ID  - Identifier
 * DEC - Decimal number
 * OCT - Octal number
 * HEX - Hexadecimal number
 * FLT - Floating point number
 */
enum {
    ID = 1024, /**< Identifier token */
    DEC,       /**< Decimal token */
    OCT,       /**< Octal token */
    HEX,       /**< Hexadecimal token */
    FLT        /**< Floating point token */
};