
/*
 * parser.c
 *
 * Recursive descent parser for LL(1) grammar of simplified expressions.
 *
 * Authors:
 *  - Felipe Melchior de Britto
 *  - João Henrique Botelho
 *  - Ryan Hideki Tadeo Guimarães
 * Date: 2025-09-04
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lexer.h>
#include <parser.h>

/**
 * Lookahead token for parser (global).
 */
int lookahead;

/**
 * E is the start symbol of the LL(1) grammar for simplified expressions.
 * E -> T R
 */
void E(void) {
    T();
    R();
}


/**
 * T non-terminal.
 * T -> F Q
 */
void T(void) {
    F();
    Q();
}


/**
 * F non-terminal.
 * F -> '(' E ')' | DEC | OCT | HEX | FLT | ID
 */
void F(void) {
    switch(lookahead) {
        case '(': 
            match('(');
            E();
            match(')');
            break;
        case DEC:
            match(DEC);
            break;
        case OCT:
            match(OCT);
            break;
        case HEX:
            match(HEX);
            break;
        case FLT:
            match(FLT);
            break;
        default:
            match(ID);
    }
}


/**
 * Q non-terminal.
 * Q -> '*' F Q | '/' F Q | epsilon
 */
void Q(void){
    switch(lookahead) {
        case '*':
            match('*');
            F();
            Q();
            break;
        case '/':
            match('/');
            F();
            Q();
            break;
        default:
            ;
    }
}


/**
 * R non-terminal.
 * R -> '+' T R | '-' T R | epsilon
 */
void R(void){
    switch(lookahead) {
        case '+':
            match('+');
            T();
            R();
            break;
        case '-':
            match('-');
            T();
            R();
            break;
        default:
            ;
    }
}


/**
 * Matches the expected token and advances lookahead.
 * If mismatch, prints error and exits.
 * @param expected Expected token value
 */
void match(int expected) {
    if ( lookahead == expected) {
        lookahead = gettoken(source);
    } else {
        fprintf(stderr, "token mismatch\n");
        exit(ERRTOKEN);
    }
}