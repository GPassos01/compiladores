// Declarações:
extern int gettoken(FILE *);
extern int lookahead;

extern void E(void);