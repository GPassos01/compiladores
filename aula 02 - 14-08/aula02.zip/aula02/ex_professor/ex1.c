#include <stdio.h>

int x = 3, y = 4, z;

int main()
{
	z = x + y;
	printf("%d\n", z);
	return 0;
}